#include "testlib.h"
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

struct Interval {
    long long a, b;
    bool operator<(const Interval& other) const {
        return a < other.a;
    }
};

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    long long n = opt<long long>("n");
    int m = opt<int>("m");
    long long max_b = opt<long long>("max_b");
    int gap_mode = opt<int>("gap_mode", 0);
    int shuffle_flag = opt<int>("shuffle", 1);

    // We must produce m intervals such that total points >= n and endpoints don't touch
    // Let's generate m disjoint intervals within [0, max_b]
    long long min_required_points = n;
    // We allocate lengths and gaps
    vector<long long> lengths(m, 1);
    long long remaining_points = max(0LL, min_required_points - m);

    // If max_b is large, we can distribute lengths
    long long max_len_sum = max_b - (m - 1);
    if (max_len_sum < min_required_points) {
        max_b = min_required_points + m + 10;
        max_len_sum = max_b - (m - 1);
    }

    long long add_pool = min(remaining_points + rnd.next(0LL, max(0LL, max_len_sum - min_required_points)), max_len_sum - m);
    // distribute add_pool among m intervals
    for (int i = 0; i < m && add_pool > 0; ++i) {
        long long take = rnd.next(0LL, add_pool);
        if (i == m - 1) take = add_pool;
        lengths[i] += take;
        add_pool -= take;
    }

    // Now distribute gaps between intervals
    long long total_len = 0;
    for (long long l : lengths) total_len += l;

    long long gap_space = max_b - total_len;
    vector<long long> gaps(m, 1); // gap before interval i, with gap[0] being offset of interval 0
    gaps[0] = 0;
    for (int i = 1; i < m; ++i) gaps[i] = 1; // at least 1 unit strictly between intervals

    long long rem_gaps = max(0LL, gap_space - (m - 1));
    for (int i = 0; i < m && rem_gaps > 0; ++i) {
        long long take = rnd.next(0LL, rem_gaps);
        if (i == m - 1) take = rem_gaps;
        gaps[i] += take;
        rem_gaps -= take;
    }

    vector<Interval> intervals(m);
    long long cur = gaps[0];
    for (int i = 0; i < m; ++i) {
        if (i > 0) cur += gaps[i];
        intervals[i].a = cur;
        intervals[i].b = cur + lengths[i] - 1;
        cur = intervals[i].b + 1;
    }

    if (shuffle_flag) {
        shuffle(intervals.begin(), intervals.end());
    }

    cout << n << " " << m << "\n";
    for (int i = 0; i < m; ++i) {
        cout << intervals[i].a << " " << intervals[i].b << "\n";
    }

    return 0;
}
