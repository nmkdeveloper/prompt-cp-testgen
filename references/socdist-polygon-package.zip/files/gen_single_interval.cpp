#include "testlib.h"
#include <iostream>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    long long n = opt<long long>("n");
    long long max_b = opt<long long>("max_b");
    long long a_start = opt<long long>("a_start", 0LL);

    long long b = max(a_start + n - 1, max_b);

    cout << n << " 1\n";
    cout << a_start << " " << b << "\n";

    return 0;
}
