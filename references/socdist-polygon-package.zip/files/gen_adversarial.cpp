#include "testlib.h"
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

struct Interval {
    long long a, b;
};

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    int mode = opt<int>("mode");
    long long n = opt<long long>("n", 100000LL);
    int m = opt<int>("m", 100000);
    long long max_b = opt<long long>("max_b", 1000000000000000000LL);

    vector<Interval> intervals;

    if (mode == 1) {
        // Extreme 10^18 coordinates, D > 10^9
        // e.g. N = 2, M = 2, interval 1 at 0..0, interval 2 at 10^18..10^18 -> D = 10^18
        n = 2;
        m = opt<int>("m", 2);
        intervals.resize(m);
        intervals[0] = {0, 0};
        long long cur = 10;
        for (int i = 1; i < m - 1; ++i) {
            intervals[i] = {cur, cur + 2};
            cur += 10;
        }
        intervals[m - 1] = {max_b, max_b};
    } else if (mode == 2) {
        // Double precision killer: values near 10^18 where double has precision 1 unit = ~2048
        // N = 3, interval 0 at [10^18 - 10000, 10^18 - 10000], interval 1 at [10^18, 10^18]
        n = 3;
        m = 2;
        long long base = 1000000000000000000LL - 1000000000LL - 500LL;
        intervals.push_back({base, base + 200});
        intervals.push_back({base + 1000000000LL, base + 1000000000LL + 200});
    } else if (mode == 3) {
        // Jump from start killer:
        // A solution that calculates capacity as (b_i - a_i) / D will fail when
        // a cow enters late into the interval (start_pos = prev + D >> a_i).
        // Let's create M intervals where D is around 10, intervals are [0, 5], [12, 25], [33, 45]...
        n = 10;
        m = 5;
        intervals.push_back({0, 5});
        intervals.push_back({7, 18});
        intervals.push_back({20, 31});
        intervals.push_back({33, 44});
        intervals.push_back({46, 57});
    } else if (mode == 4) {
        // Predicate off-by-one killer:
        // Exactly N cows fit with distance D, last cow lands exactly on b_M.
        // N = 5, D = 4: cow positions 0, 4, 8, 12, 16.
        // Intervals: [0, 0], [4, 4], [8, 8], [12, 12], [16, 16].
        n = 5;
        m = 5;
        long long D = 10;
        for (int i = 0; i < n; ++i) {
            intervals.push_back({i * D, i * D});
        }
    } else if (mode == 5) {
        // Linear search killer:
        // D is large (e.g. 10^8 or 10^9), N = 2, M = 2.
        // Linear search iterates 10^8 times -> TLE under 1.0s.
        n = 2;
        m = 2;
        intervals.push_back({0, 0});
        intervals.push_back({max_b, max_b});
    } else if (mode == 6) {
        // Unsorted killer at scale:
        // Reverse order of sorted intervals!
        intervals.resize(m);
        long long cur = 0;
        for (int i = 0; i < m; ++i) {
            long long len = 2;
            intervals[i] = {cur, cur + len - 1};
            cur += len + 2;
        }
        reverse(intervals.begin(), intervals.end());
    } else if (mode == 7) {
        // Max boundary test: N = 10^5, M = 10^5, max_b = 10^18
        n = 100000;
        m = 100000;
        intervals.resize(m);
        long long span = 1000000000000000000LL / m; // ~ 10^13 per interval
        for (int i = 0; i < m; ++i) {
            long long a = i * span;
            long long b = a + rnd.next(1LL, min(100LL, span - 2));
            intervals[i] = {a, b};
        }
        shuffle(intervals.begin(), intervals.end());
    }

    cout << n << " " << intervals.size() << "\n";
    for (const auto& iv : intervals) {
        cout << iv.a << " " << iv.b << "\n";
    }

    return 0;
}
