#include "testlib.h"
#include <vector>
#include <algorithm>

using namespace std;

struct Interval {
    long long a, b;
    bool operator<(const Interval& other) const {
        return a < other.a;
    }
};

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    long long n = inf.readLong(2LL, 100000LL, "N");
    inf.readSpace();
    int m = inf.readInt(1, 100000, "M");
    inf.readEoln();

    vector<Interval> intervals(m);
    long long total_points = 0;
    bool overflow_safe = false;

    for (int i = 0; i < m; ++i) {
        intervals[i].a = inf.readLong(0LL, 1000000000000000000LL, "a_i");
        inf.readSpace();
        intervals[i].b = inf.readLong(intervals[i].a, 1000000000000000000LL, "b_i");
        inf.readEoln();

        if (!overflow_safe) {
            long long pts = intervals[i].b - intervals[i].a + 1;
            total_points += pts;
            if (total_points >= n) {
                overflow_safe = true;
            }
        }
    }
    inf.readEof();

    vector<Interval> sorted_intervals = intervals;
    sort(sorted_intervals.begin(), sorted_intervals.end());

    for (int i = 0; i < m - 1; ++i) {
        ensuref(sorted_intervals[i].b < sorted_intervals[i + 1].a,
                "Intervals [%lld, %lld] and [%lld, %lld] overlap or touch",
                sorted_intervals[i].a, sorted_intervals[i].b,
                sorted_intervals[i + 1].a, sorted_intervals[i + 1].b);
    }

    ensuref(overflow_safe || total_points >= n, "Cannot place %lld cows even with D=1", n);

    return 0;
}
