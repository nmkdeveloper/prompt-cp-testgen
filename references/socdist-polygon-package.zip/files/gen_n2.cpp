#include "testlib.h"
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

struct Interval {
    long long a, b;
};

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    int m = opt<int>("m");
    long long max_b = opt<long long>("max_b");
    int shuffle_flag = opt<int>("shuffle", 1);

    vector<Interval> intervals(m);
    // Interval 0 starts at a_0
    long long cur = rnd.next(0LL, 100LL);
    for (int i = 0; i < m - 1; ++i) {
        long long len = rnd.next(1LL, 10LL);
        intervals[i].a = cur;
        intervals[i].b = cur + len - 1;
        cur = intervals[i].b + 1 + rnd.next(1LL, 10LL);
    }
    // Last interval reaches up to max_b
    intervals[m - 1].a = max(cur, max_b - rnd.next(0LL, 100LL));
    intervals[m - 1].b = max(intervals[m - 1].a, max_b);

    if (shuffle_flag) {
        shuffle(intervals.begin(), intervals.end());
    }

    cout << "2 " << m << "\n";
    for (int i = 0; i < m; ++i) {
        cout << intervals[i].a << " " << intervals[i].b << "\n";
    }

    return 0;
}
