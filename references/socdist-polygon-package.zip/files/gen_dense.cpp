#include "testlib.h"
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

struct Interval {
    long long a, b;
};

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    long long n = opt<long long>("n");
    int m = opt<int>("m");
    long long max_b = opt<long long>("max_b");
    int shuffle_flag = opt<int>("shuffle", 1);

    // Dense: intervals are short and separated by minimum gap 1 or small random gap
    vector<Interval> intervals(m);
    long long cur = rnd.next(0LL, 10LL);

    for (int i = 0; i < m; ++i) {
        long long len = rnd.next(1LL, 5LL);
        intervals[i].a = cur;
        intervals[i].b = cur + len - 1;
        cur = intervals[i].b + 1 + rnd.next(1LL, 3LL);
    }

    // Ensure total points >= n
    long long total_pts = 0;
    for (const auto& iv : intervals) total_pts += (iv.b - iv.a + 1);
    if (total_pts < n) {
        intervals.back().b += (n - total_pts);
    }

    if (shuffle_flag) {
        shuffle(intervals.begin(), intervals.end());
    }

    cout << n << " " << m << "\n";
    for (int i = 0; i < m; ++i) {
        cout << intervals[i].a << " " << intervals[i].b << "\n";
    }

    return 0;
}
