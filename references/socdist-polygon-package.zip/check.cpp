#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);

    long long ja = ans.readLong();
    long long pa = ouf.readLong();

    if (ja != pa) {
        quitf(_wa, "expected %lld, found %lld", ja, pa);
    }

    quitf(_ok, "correct: %lld", ja);
}
