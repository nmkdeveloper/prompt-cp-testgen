#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// WRONG: computes capacity in interval as (b - a) / D instead of (b - start_pos) / D
struct Interval {
    long long a, b;
    bool operator<(const Interval& other) const {
        return a < other.a;
    }
};

bool check(long long D, const vector<Interval>& intervals, long long n) {
    long long count = 0;
    long long current_pos = 0;
    bool has_placed_first = false;

    for (size_t i = 0; i < intervals.size(); ++i) {
        if (!has_placed_first) {
            long long can_place = 1 + (intervals[i].b - intervals[i].a) / D;
            count += can_place;
            current_pos = intervals[i].a + (can_place - 1) * D;
            has_placed_first = true;
        } else {
            long long start_pos = max(intervals[i].a, current_pos + D);
            if (start_pos <= intervals[i].b) {
                // Bug: ignores start_pos offset and calculates using (b - a) / D
                long long can_place = 1 + (intervals[i].b - intervals[i].a) / D;
                count += can_place;
                current_pos = intervals[i].b;
            }
        }
        if (count >= n) return true;
    }
    return count >= n;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    int m;
    if (!(cin >> n >> m)) return 0;

    vector<Interval> intervals(m);
    for (int i = 0; i < m; ++i) {
        cin >> intervals[i].a >> intervals[i].b;
    }

    sort(intervals.begin(), intervals.end());

    long long low = 1;
    long long high = (intervals.back().b - intervals.front().a) / (n - 1);
    long long ans = 1;

    while (low <= high) {
        long long mid = low + (high - low) / 2;
        if (check(mid, intervals, n)) {
            ans = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    cout << ans << "\n";
    return 0;
}
