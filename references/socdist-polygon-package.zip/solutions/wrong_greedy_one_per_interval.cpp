#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// WRONG: places at most one cow per interval
struct Interval {
    long long a, b;
    bool operator<(const Interval& other) const {
        return a < other.a;
    }
};

bool check(long long D, const vector<Interval>& intervals, long long n) {
    long long count = 0;
    long long current_pos = 0;
    bool has_placed_first = false;

    for (size_t i = 0; i < intervals.size(); ++i) {
        long long start_pos;
        if (!has_placed_first) {
            start_pos = intervals[i].a;
            has_placed_first = true;
            count++;
            current_pos = start_pos;
        } else {
            start_pos = max(intervals[i].a, current_pos + D);
            if (start_pos <= intervals[i].b) {
                count++;
                current_pos = start_pos;
            }
        }
        if (count >= n) return true;
    }
    return count >= n;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    int m;
    if (!(cin >> n >> m)) return 0;

    vector<Interval> intervals(m);
    for (int i = 0; i < m; ++i) {
        cin >> intervals[i].a >> intervals[i].b;
    }

    sort(intervals.begin(), intervals.end());

    long long low = 1;
    long long high = (intervals.back().b - intervals.front().a) / (n - 1);
    long long ans = 1;

    while (low <= high) {
        long long mid = low + (high - low) / 2;
        if (check(mid, intervals, n)) {
            ans = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    cout << ans << "\n";
    return 0;
}
