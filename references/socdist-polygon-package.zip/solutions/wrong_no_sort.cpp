#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// WRONG: assumes input intervals are already sorted
struct Interval {
    long long a, b;
};

bool check(long long D, const vector<Interval>& intervals, long long n) {
    long long count = 0;
    long long current_pos = 0;
    bool has_placed_first = false;

    for (size_t i = 0; i < intervals.size(); ++i) {
        long long start_pos;
        if (!has_placed_first) {
            start_pos = intervals[i].a;
            has_placed_first = true;
        } else {
            start_pos = max(intervals[i].a, current_pos + D);
        }

        if (start_pos <= intervals[i].b) {
            long long can_place = 1 + (intervals[i].b - start_pos) / D;
            count += can_place;
            current_pos = start_pos + (can_place - 1) * D;
            if (count >= n) return true;
        }
    }
    return count >= n;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    int m;
    if (!(cin >> n >> m)) return 0;

    vector<Interval> intervals(m);
    for (int i = 0; i < m; ++i) {
        cin >> intervals[i].a >> intervals[i].b;
    }

    // No sort!

    long long low = 1;
    long long high = 1000000000000000000LL;
    long long ans = 1;

    while (low <= high) {
        long long mid = low + (high - low) / 2;
        if (check(mid, intervals, n)) {
            ans = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    cout << ans << "\n";
    return 0;
}
