#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// WRONG: uses 32-bit int instead of long long
struct Interval {
    int a, b;
    bool operator<(const Interval& other) const {
        return a < other.a;
    }
};

bool check(int D, const vector<Interval>& intervals, int n) {
    int count = 0;
    int current_pos = 0;
    bool has_placed_first = false;

    for (size_t i = 0; i < intervals.size(); ++i) {
        int start_pos;
        if (!has_placed_first) {
            start_pos = intervals[i].a;
            has_placed_first = true;
        } else {
            start_pos = max(intervals[i].a, current_pos + D);
        }

        if (start_pos <= intervals[i].b) {
            int can_place = 1 + (intervals[i].b - start_pos) / D;
            count += can_place;
            current_pos = start_pos + (can_place - 1) * D;
            if (count >= n) return true;
        }
    }
    return count >= n;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;
    if (!(cin >> n >> m)) return 0;

    vector<Interval> intervals(m);
    for (int i = 0; i < m; ++i) {
        cin >> intervals[i].a >> intervals[i].b;
    }

    sort(intervals.begin(), intervals.end());

    int low = 1;
    int high = (intervals.back().b - intervals.front().a) / (n - 1);
    int ans = 1;

    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (check(mid, intervals, n)) {
            ans = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    cout << ans << "\n";
    return 0;
}
