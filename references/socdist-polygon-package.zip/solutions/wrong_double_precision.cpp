#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

// WRONG: uses double precision for binary search and coordinates, precision loss around 1e18
struct Interval {
    double a, b;
    bool operator<(const Interval& other) const {
        return a < other.a;
    }
};

bool check(double D, const vector<Interval>& intervals, double n) {
    double count = 0;
    double current_pos = 0;
    bool has_placed_first = false;

    for (size_t i = 0; i < intervals.size(); ++i) {
        double start_pos;
        if (!has_placed_first) {
            start_pos = intervals[i].a;
            has_placed_first = true;
        } else {
            start_pos = max(intervals[i].a, current_pos + D);
        }

        if (start_pos <= intervals[i].b) {
            double can_place = 1 + floor((intervals[i].b - start_pos) / D);
            count += can_place;
            current_pos = start_pos + (can_place - 1) * D;
            if (count >= n) return true;
        }
    }
    return count >= n;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    double n;
    int m;
    if (!(cin >> n >> m)) return 0;

    vector<Interval> intervals(m);
    for (int i = 0; i < m; ++i) {
        cin >> intervals[i].a >> intervals[i].b;
    }

    sort(intervals.begin(), intervals.end());

    double low = 1;
    double high = (intervals.back().b - intervals.front().a) / (n - 1);
    double ans = 1;

    for (int iter = 0; iter < 70; ++iter) {
        double mid = floor(low + (high - low) / 2);
        if (mid < low) mid = low;
        if (check(mid, intervals, n)) {
            ans = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
        if (low > high) break;
    }

    cout << (long long)ans << "\n";
    return 0;
}
