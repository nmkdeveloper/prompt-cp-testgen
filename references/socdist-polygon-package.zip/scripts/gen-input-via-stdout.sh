#!/usr/bin/env bash
"$@" > input.txt
