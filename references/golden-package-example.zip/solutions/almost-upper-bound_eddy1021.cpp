#include <bits/stdc++.h>
using namespace std;
int n, k;
vector<int> v;
int main(){
  scanf("%d%d", &n, &k);
  v.resize(n);
  for(int i=0; i<n; i++)
    scanf("%d", &v[i]);
  sort(v.begin(), v.end());
  int ans=(k==0?1:v[k-1]);
  for(int i=0; i<n; i++)
    if(v[i]<=ans)
      k--;
  if(k != 0) ans=-1;
  printf("%d\n", ans);
}
