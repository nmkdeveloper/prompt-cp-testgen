n, k = map(int, input().split())
a = list(map(int, input().split()))

a.sort()

ans = 0
if (k == 0):
	ans = a[0] - 1
else:
	ans = a[k - 1]
	
cnt = 0
for it in a:
	if (it <= ans):
		cnt += 1
		
if (cnt == k and (1 <= ans and ans <= 10 ** 9)):
	print(ans)
else:
	print(-1)