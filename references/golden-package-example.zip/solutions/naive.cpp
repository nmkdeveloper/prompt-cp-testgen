#include <bits/stdc++.h>

#define forn(i, n) for (int i = 0; i < int(n); i++)

using namespace std;

int main() {
    int n, k;
    cin >> n >> k;
    vector<int> a(n);
    forn(i, n)
        cin >> a[i];
    forn(i, n)
        for (int x = a[i] - 1; x <= a[i] + 1; x++)
            if (1 <= x && x <= 1000000000) {
                int cnt = 0;
                forn(j, n)
                    if (a[j] <= x)
                        cnt++;
                if (cnt == k) {
                    cout << x << endl;
                    return 0;
                }
            }
    cout << -1 << endl;
}
