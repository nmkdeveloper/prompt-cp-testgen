#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	int n = atoi(argv[1]);
	int k = atoi(argv[2]);
	
	vector<int> a(n);
	for (int i = 0; i < n; ++i)
		a[i] = rnd.next(1, 1000 * 1000 * 1000);	
		
	println(n, k);
	println(a);
}