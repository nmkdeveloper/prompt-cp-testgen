#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);
	
	int n = atoi(argv[1]);
	int k = atoi(argv[2]);
	int cnt = atoi(argv[3]);
	
	vector<int> a(n);
	for (int i = 0; i < cnt; ++i)
		a[i] = 1;
		
	for (int i = cnt; i < n; ++i)
		a[i] = rnd.next(2, 1000 * 1000 * 1000);
		
	shuffle(a.begin(), a.end());
		
	println(n, k);
	println(a);
}