#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);
	
	int n = atoi(argv[1]);
	int noanswer = atoi(argv[2]);
	
	bool ok = false;
	int cnt = -1;
	
	vector<int> a(n);
	while (!ok) {
		for (int i = 0; i < n; ++i)
			a[i] = rnd.next(1, 1000 * 1000 * 1000);	
		sort(a.begin(), a.end());
		for (int i = 0; i < n - 1; ++i) {
			if (a[i] == a[i + 1]) {
				ok = true;
				cnt = i;
			}
		}
	}
	
	shuffle(a.begin(), a.end());

	println(n, cnt + noanswer);
	println(a);
}