#include <bits/stdc++.h>
#include "testlib.h"

#define forn(i, n) for (int i = 0; i < int(n); i++)

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    int n = atoi(argv[1]);
    println(n, rnd.next(0, n));

    int m;
    if (rnd.next(2) == 0)
        m = 2 * n;
    else
        m = 1000000000;

    vector<int> a(n);
    int weight = rnd.next(-5, 5);
    forn(i, n)
        a[i] = rnd.wnext(1, m, weight);
    println(a);
}
